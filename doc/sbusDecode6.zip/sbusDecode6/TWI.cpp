/*  TWI (I2C) non-blocking interrupt driven.  Currently only supports master transmit mode
 *  ceptimus.  September 2016
 */
#include "TWI.h"

uint8_t TWI::slaveAddr;
uint8_t *TWI::data;
uint8_t TWI::remaining;
callbackPtr TWI::callback;

void TWI::TWIstart(void) { // configure for two wire interface operation
  // for 'standard' 400 kHz SCL frequency, set TWSR = 1 and TWBR = 3.  
  TWSR = 1; // set prescaler to 4
  TWBR = 3; // SCL = CPU clock / (16 + 2 * TWBR * prescaler) 16M / (16 + 2 * 3 * 4) = 400kHz
}

void TWI::nonBlockingTWImasterTransmit(uint8_t slave, uint8_t bytes[], uint8_t length, callbackPtr cback) {
  slaveAddr = slave;
  callback = cback;
  remaining = length;
  data = bytes;

  TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN) | (1 << TWIE); // send START condition and enable TWI interrupts
}

ISR(TWI_vect) { // TWI interrupt has occurred meaning that TWINT flag has been set
  uint8_t statusCode = TWSR & 0xF8;
  switch(statusCode) {
    case 0x08: // normal response to a START
      TWDR = TWI::slaveAddr << 1; // send slave address (and enter master transmit mode)
      TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWIE); // transmit address
      break;
    case 0x10: // normal response to a repeated START
      break;
    case 0x18: // normal response to slave address
      TWI::remaining--;
      TWDR = *TWI::data++; // send first byte of data
      TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWIE); // send data byte
      break;
    case 0x28: // normal response to data byte
      if (TWI::remaining) { // still have more data to transmit
        TWI::remaining--;
        TWDR = *TWI::data++; // send next byte of data
        TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWIE); // send data byte
      } else { // all data sent
        TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN) | (1 << TWIE); // send STOP condition
        sei(); // allow interrupts during callback
        TWI::callback(/* 1 */); // this can't be a response code as the Status Register is anded with F8
      }
      break;
    case 0x38: // arbitration lost
      TWCR = (1 << TWINT) | (1 << TWEN); // disable further interrupts, release TW serial bus and enter slave mode
      sei(); // allow interrupts during callback
      TWI::callback(/* statusCode */);
      break;
    default: // unexpected response
      TWCR = TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN); // disable further interrupts, send STOP condition
      sei(); // allow interrupts during callback
      TWI::callback(/* statusCode */);
      break;
  } 
}




