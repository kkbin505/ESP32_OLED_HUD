/*  TWI (I2C) non-blocking code to drive 128x64 monochrome oled display module using non-blocking TWI
 *  ceptimus.  September 2016
 */
#ifndef display_h
#define display_h

#include "config.h"

#ifdef DS160120
  #include "font7x10.h"
#else
  #include "font6x8.h"
#endif

const uint8_t stretch[] PROGMEM = {0x00, 0x03, 0x0C, 0x0F, 0x30, 0x33, 0x3C, 0x3F, 0xC0, 0xC3, 0xCC, 0xCF, 0xF0, 0xF3, 0xFC, 0xFF}; // pixel doubling look-up for double-size 'large' characters

#include "TWI.h"

// choose display address based on selected display type - configure addresses if necessary by editing config.h
#ifdef SH1106
  #define DISPLAY_I2C_ADDRESS SH1106_ADDR
#endif
#ifdef SSD1306
  #define DISPLAY_I2C_ADDRESS SSD1306_ADDR
#endif
#ifdef DS12864
  #define DISPLAY_I2C_ADDRESS DS12864_ADDR
#endif
#ifdef DS160120
  #define DISPLAY_I2C_ADDRESS DS160120_ADDR
#endif

#ifdef NEGATIVE_DISPLAY
  #define DIGOLE_INK 1
#else
  #define DIGOLE_INK 0
#endif

// following #defines written for OLED 128x64 displays and are largely ignored by the Digole displays - especially the larger one which uses a different font and cell size
// pixels
#define DISPLAY_LCDWIDTH  128
#define DISPLAY_LCDHEIGHT  64

// display chars assuming 6x8 font
#define DISPLAY_CHARWIDTH (DISPLAY_LCDWIDTH / 6)
#define DISPLAY_CHARHEIGHT (DISPLAY_LCDHEIGHT / 8)
#define DISPLAY_NUMCHARS (DISPLAY_CHARWIDTH * DISPLAY_CHARHEIGHT)

// there may be unused pixels down each side of the display - for example with a 128 pixel-width display and a 6-bit-wide font there are 21 characters per row with 1 unused pixel down each edge
#define DISPLAY_LEFTMARGIN ((DISPLAY_LCDWIDTH - DISPLAY_CHARWIDTH * 6) / 2)  
// (unlikely to need a TOPMARGIN as displays are all likely to be a multiple of 8 pixels high - in any case we'll manage okay without)

// give names to the command bytes the display module understands - see datasheet.
#define DISPLAY_SETCONTRAST 0x81
#define DISPLAY_DISPLAYALLON_RESUME 0xA4
#define DISPLAY_DISPLAYALLON 0xA5
#define DISPLAY_NORMALDISPLAY 0xA6
#define DISPLAY_INVERTDISPLAY 0xA7
#define DISPLAY_DISPLAYOFF 0xAE
#define DISPLAY_DISPLAYON 0xAF

#define DISPLAY_SETDISPLAYOFFSET 0xD3
#define DISPLAY_SETCOMPINS 0xDA

#define DISPLAY_SETVCOMDETECT 0xDB

#define DISPLAY_SETDISPLAYCLOCKDIV 0xD5
#define DISPLAY_SETPRECHARGE 0xD9

#define DISPLAY_SETMULTIPLEX 0xA8

#define DISPLAY_SETLOWCOLUMN 0x00
#define DISPLAY_SETHIGHCOLUMN 0x10

#define DISPLAY_COLUMNADDR 0x21
#define DISPLAY_PAGEADDR   0x22

#define DISPLAY_SETSTARTLINE 0x40
#define DISPLAY_SETSTARTPAGE 0XB0
#define DISPLAY_MEMORYMODE 0x20

#define DISPLAY_COMSCANINC 0xC0
#define DISPLAY_COMSCANDEC 0xC8

#define DISPLAY_SEGREMAP 0xA0

#define DISPLAY_CHARGEPUMP 0x8D

#define DISPLAY_EXTERNALVCC 0x1
#define DISPLAY_SWITCHCAPVCC 0x2

class _display {
  public:
    static void start(void);
    static void fillDisplay(uint8_t c); // fill whole display with (c) characters.  c is most likely ' ' or (' ' | 0x80) for reversed field
    static void displayCharSmall(uint8_t row, uint8_t col, char c, uint8_t rvsField); // if rvsField != 0 display character in string with reversed field
    static void displayStringSmall(uint8_t row, uint8_t col, const char *s, uint8_t rvsField); // if rvsField != 0 display characters in string with reversed field
    static void displayStringSmall(uint8_t row, uint8_t col, const __FlashStringHelper *s, uint8_t rvsField); // same as above for constant (FLASH memory) stored strings
    static void highlightSmall(uint8_t row, uint8_t col, uint8_t len, uint8_t rvsField); // change indicated area of display to rvsField (on or off)
    static void displayStringLarge(uint8_t row, uint8_t col, const char *s, uint8_t rvsField);
    static void displayStringLarge(uint8_t row, uint8_t col, const __FlashStringHelper *s, uint8_t rvsField);
    static void scClear(uint8_t c); // clear soft character c = 2~31
    static void scSetPixel(uint8_t c, uint8_t p); // set pixel in soft character c = 2~31, p = 0~47 starting top left  p = 7 is bottom left, p = 47 is bottom right
    static void scResetPixel(uint8_t c, uint8_t p);
#if defined(DS12864) || defined(DS160120)
    static void finishRefreshChar(void);
#endif
  private:
    static uint32_t softCharChanged; // bit array to keep track of when a soft char has been modified
    static uint8_t displayBuffer[]; // holds array of ASCII values for the current display.  Nominally 21 x 8 chars for 6x8 font on a 128x64 display
    static uint8_t scBuffer[]; // holds data for the 30 soft characters - each 6x8 pixels
    static uint8_t dataBuffer[]; // holds current queue of bytes to be sent by TWI to display
    static uint8_t refreshed[]; // bit array keeping track of whether the interrupt-driven routines have refreshed each display char.  For the 21 x 8 case this is 168 bits - so 21 bytes
    static uint16_t refreshPtr; // screen is refreshed in downward vertical stripes starting from the left.  for the 168-char display this need only be 8 bits, but uses 16 bits to allow for possible future bigger displays.
    static void refreshChar(void); // refresh the character pointed to by refreshPtr
    static uint8_t startup;
    static volatile bool idle;  
    static uint8_t* queuePtr;
    static void transmit(/* uint8_t result */);    
    static void transmitCharSmall(uint8_t row, uint8_t x, uint8_t c);
    static void transmitCharLarge(uint8_t row, uint8_t x, uint8_t c);
    static void transmitSoftCharSmall(uint8_t row, uint8_t x, uint8_t c);
    static uint8_t queueCommands(uint8_t *buff, uint8_t numCommands, uint8_t *commands);
    static void bufferChar(uint8_t row, uint8_t col, uint8_t c, int16_t *first);
    static void bufferDoubleChar(uint8_t row, uint8_t col, uint8_t c, int16_t *first);
    static bool isChangedSoftChar(uint8_t c);
};

#endif

