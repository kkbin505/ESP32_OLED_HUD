/*  TWI (I2C) non-blocking interrupt driven.  Currently only supports master transmit mode
 *  ceptimus.  September 2016
 */
#ifndef TWI_h
#define TWI_h
#include "config.h"

typedef void (*callbackPtr)(/* uint8_t */ void);

class TWI {
  public:    
    static void TWIstart(void); // configure TWI registers (sets communication speed)
    static void nonBlockingTWImasterTransmit(uint8_t slaveAddr, uint8_t data[], uint8_t length, callbackPtr callback);
  // following are only public so they can be accessed by the (non-member) ISR
    static uint8_t slaveAddr;
    static uint8_t *data; // data pointer for non-blocking interrupt routine
    static uint8_t remaining; // count of remaining data bytes to be sent by non-blocking interrupt routine
    static callbackPtr callback;
};
#endif
