/*  TWI (I2C) non-blocking code to drive 128x64 monochrome oled display module using non-blocking TWI
 *  ceptimus.  September 2016
 */
#include "display.h"
#if defined(DS12864) || defined(DS160120)
#include "timer1callback.h"
#endif

uint8_t _display::displayBuffer[DISPLAY_NUMCHARS];
uint8_t _display::refreshed[(DISPLAY_NUMCHARS + 7) / 8];
uint8_t _display::dataBuffer[80];
#ifdef DS160120
uint8_t _display::scBuffer[360]; // 30 chars * 12 bytes each
#else
uint8_t _display::scBuffer[180]; // 30 chars * 6 bytes each
#endif
uint32_t _display::softCharChanged;
uint8_t *_display::queuePtr;
uint16_t _display::refreshPtr;
#if defined(DS12864) || defined(DS160120)
uint16_t oldRefreshPtr;
#endif
volatile bool _display::idle;
uint8_t _display::startup;

void _display::fillDisplay(uint8_t c) { // fill whole display using character c
  int16_t i;
  int16_t changed = -1;
   
  for (i = 0; i < DISPLAY_NUMCHARS; i++) {
    if (displayBuffer[i] != c) {
      displayBuffer[i] = c;
      refreshed[i / 8] &= ~(1 << (i & 0x0007)); // mark character as unrefreshed  
      changed = i; // remember where last unrefreshed character (if any) was
    }
  }
  
  if (idle && (changed >= 0)) { // kick TWI interrupts back into life if necessary
    refreshPtr = changed;
    refreshChar();
  }
}

void _display::start(void) {
  TWI::TWIstart();
  refreshPtr = 0; // initialize refreshPTR to top left hand corner of screen
  idle = false; // don't want fillDisplay to kick off interrupts yet, so pretend we're busy
  fillDisplay(' '); // initialize displayBuffer with spaces
  
  // once the initial setup command bytes have been processed, we next want to clear unused pixels down both display vertical edges using space characters 
#if defined(DS12864) || defined(DS160120)
  startup = 0; // don't need to clear edges for these display types
#else
  startup = (DISPLAY_LCDHEIGHT / 8) * 2; // this is a count of how many spaces remain to be sent
#endif


  // queue up the initial setup commands for the display
#ifdef SH1106
  uint8_t commandQueue[23] = {
    DISPLAY_DISPLAYOFF,
    0x40, // display start line
    DISPLAY_SETCONTRAST, 0x80,
    DISPLAY_SEGREMAP | 0x01,
    DISPLAY_NORMALDISPLAY,
    DISPLAY_SETMULTIPLEX, 0x3F,
    0xAD, 0x8B, // charge pump enable, external VCC
    0x30, // VPP 9V
    DISPLAY_COMSCANDEC,
    DISPLAY_SETDISPLAYOFFSET, 0x00,
    DISPLAY_SETDISPLAYCLOCKDIV, 0x80,
    DISPLAY_SETPRECHARGE, 0x22,
    DISPLAY_SETCOMPINS, 0x12,
    DISPLAY_SETVCOMDETECT, 0x40,
    DISPLAY_DISPLAYON
  };
  uint8_t dataStart = queueCommands(dataBuffer, 23, commandQueue);
#endif

#ifdef SSD1306  
  uint8_t commandQueue[24] = {
    DISPLAY_SETMULTIPLEX, 0x3F,
    DISPLAY_SETDISPLAYOFFSET, 0x00,
    DISPLAY_SETSTARTLINE,
    DISPLAY_SEGREMAP | 0x01,
    DISPLAY_COMSCANDEC,
    DISPLAY_SETCOMPINS, 0x12,
    DISPLAY_SETCONTRAST, 0xFF,
    DISPLAY_DISPLAYALLON_RESUME,
    DISPLAY_NORMALDISPLAY,
    DISPLAY_SETDISPLAYCLOCKDIV, 0x80,
    DISPLAY_CHARGEPUMP, 0x14,
    DISPLAY_SETPRECHARGE, 0x22,
    DISPLAY_MEMORYMODE, 0x01,
    DISPLAY_SETVCOMDETECT, 0x20,
    DISPLAY_DISPLAYON
  };
  uint8_t dataStart = queueCommands(dataBuffer, 24, commandQueue);
#endif

#ifdef DS12864
  uint8_t dataStart = queueCommands(dataBuffer, 4, (uint8_t *)"DSS\x00"); // DSS disable start screen
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"DC\x00"); // "DC" - disable configuration
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"\x1B\x45\x00"); // "BGC" - paper color white
  dataStart += queueCommands(dataBuffer + dataStart, 2, (uint8_t *)"CL"); // clear screen
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"SC\x01"); // ink color black
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"\x1B\x28\x00"); // "INV"
  dataBuffer[dataStart - 1] = DIGOLE_INK; // edit DIGOLE_INK in config.h to choose 0 = black ink on white background, or 1 = vice versa
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"SD\x03"); // Set Direction to 3 - puts origin bottom left with x increasing bottom to top and y increasing left to right
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"FS\x01"); // Refresh screen when idle
#endif

#ifdef DS160120
  uint8_t dataStart = queueCommands(dataBuffer, 4, (uint8_t *)"DSS\x00"); // DSS disable start screen
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"DC\x00"); // "DC" - disable configuration
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"\x1B\x45\x00"); // "BGC" - paper color white
  dataStart += queueCommands(dataBuffer + dataStart, 2, (uint8_t *)"CL"); // clear screen
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"SC\x01"); // ink color black
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"\x1B\x28\x00"); // "INV"
  dataBuffer[dataStart - 1] = DIGOLE_INK; // edit DIGOLE_INK in config.h to choose 0 = black ink on white background, or 1 = vice versa
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"SD\x00"); // Set Direction to 0 - puts origin top left with x increasing left to right and y increasing top to bottom
  dataStart += queueCommands(dataBuffer + dataStart, 3, (uint8_t *)"FS\x01"); // Refresh screen when idle
#endif

  dataBuffer[dataStart] = 0; // mark end of data with a zero-length packet
  queuePtr = dataBuffer;
  transmit(/* 1 */);
}

// tests if a soft char has been modified since last use - if so returns true and marks char as no longer modified
// could go wrong if same char is used at more than one location on screen - but that doesn't happen in Reedy Ten unless the soft char occupying a particular screen position is changed anyway
bool _display::isChangedSoftChar(uint8_t c) { 
  c &= 0x7F; // mask rvsfield bit
  if ((c < 2) || (c > 31)) return false; // not a soft char
  uint32_t mask = 0x01UL << c;
  if ((softCharChanged & mask) != 0UL) { // soft char has been modified
    softCharChanged ^= mask; // mark as no longer modified
    return true;
  }
  return false;
}

void _display::bufferChar(uint8_t row, uint8_t col, uint8_t c, int16_t *first) {
  if (col > DISPLAY_CHARWIDTH - 1) {
    col = DISPLAY_CHARWIDTH - 1;
  }
  int16_t posn = col * DISPLAY_CHARHEIGHT + row;
  if (isChangedSoftChar(c) || (displayBuffer[posn] != c)) { // if character is a soft character that's been modified or any char new to this row,col position
    displayBuffer[posn] = c;
    refreshed[posn / 8] &= ~(1 << (posn & 0x0007)); // mark character as unrefreshed
    if (*first < 0) {  
      *first = posn; // remember where first unrefreshed character (if any) was
    }
  }  
}

void _display::highlightSmall(uint8_t row, uint8_t col, uint8_t len, uint8_t rvsField) { 
  if (row > DISPLAY_CHARHEIGHT - 1) {
    row = DISPLAY_CHARHEIGHT - 1;
  }
  if (rvsField) { rvsField = 0x80; }
  int16_t first = -1;
  
  for (uint8_t i = 0; i < len; i++) {
    uint8_t c = (displayBuffer[col * DISPLAY_CHARHEIGHT + row] & 0x7F) | rvsField;  
    bufferChar(row, col++, c, &first);
  } 
  if (idle && (first >= 0)) { // kick TWI interrupts back into life if necessary
    refreshPtr = first;
    refreshChar();
  }
}

void _display::displayCharSmall(uint8_t row, uint8_t col, const char c, uint8_t rvsField) {
  if (row > DISPLAY_CHARHEIGHT - 1) {
    row = DISPLAY_CHARHEIGHT - 1;
  }
  if (rvsField) { rvsField = 0x80; }
  int16_t first = -1;
  
  bufferChar(row, col++, c ^ rvsField, &first);
  
  if (idle && (first >= 0)) { // kick TWI interrupts back into life if necessary
    refreshPtr = first;
    refreshChar();
  }
}
 
void _display::displayStringSmall(uint8_t row, uint8_t col, const char *s, uint8_t rvsField) {
  if (row > DISPLAY_CHARHEIGHT - 1) {
    row = DISPLAY_CHARHEIGHT - 1;
  }
  if (rvsField) { rvsField = 0x80; }
  int16_t first = -1;
  
  while (uint8_t c = *s++) {
    bufferChar(row, col++, c ^ rvsField, &first);
  }
  
  if (idle && (first >= 0)) { // kick TWI interrupts back into life if necessary
    refreshPtr = first;
    refreshChar();
  }
}

void _display::displayStringSmall(uint8_t row, uint8_t col, const __FlashStringHelper *s, uint8_t rvsField) {
  if (rvsField) { rvsField = 0x80; }
  int16_t first = -1;
  uint8_t *p = (uint8_t PROGMEM *)s;
  while (uint8_t c = pgm_read_byte_near(p++)) {
     bufferChar(row, col++, c ^ rvsField, &first);
  }
  
  if (idle && (first >= 0)) { // kick TWI interrupts back into life if necessary
    refreshPtr = first;
    refreshChar();
  }
}

void _display::bufferDoubleChar(uint8_t row, uint8_t col, uint8_t c, int16_t *first) {
  if (col > DISPLAY_CHARWIDTH - 2) {
    col = DISPLAY_CHARWIDTH - 2;
  }
  int16_t posn = col * DISPLAY_CHARHEIGHT + row;
  if (displayBuffer[posn+1] != c) {
    displayBuffer[posn+1] = c; // the character code goes in the bottom left hand corner of the 2x2 grid the character occupies
    refreshed[(posn+1) / 8] |= (1 << ((posn+1) & 0x0007)); // and it doesn't need to be refreshed
    displayBuffer[posn+DISPLAY_CHARHEIGHT] = 0; 
    displayBuffer[posn+DISPLAY_CHARHEIGHT+1] = 0;// special 'ignore code 0' characters go in the two right hand cells of the 2x2 grid the character occupies
    refreshed[(posn+DISPLAY_CHARHEIGHT) / 8] |= (1 << ((posn+DISPLAY_CHARHEIGHT) & 0x0007)); 
    refreshed[(posn+DISPLAY_CHARHEIGHT+1) / 8] |= (1 << ((posn+DISPLAY_CHARHEIGHT+1) & 0x0007)); // and they don't need to be refreshed either
    
    bufferChar(row, col, 1, first); // the special double-size marker code (1) goes in the top left corner of the 2x2 grid
    refreshed[posn / 8] &= ~(1 << (posn & 0x0007)); // mark character as unrefreshed
    *first = posn; // character has changed so set first refreshed character
  }   
}

void _display::displayStringLarge(uint8_t row, uint8_t col, const char *s, uint8_t rvsField) {
  if (row > DISPLAY_CHARHEIGHT - 2) {
    row = DISPLAY_CHARHEIGHT - 2;
  }
  if (rvsField) { rvsField = 0x80; }
  int16_t first = -1;
  
  while (uint8_t c = *s++) {
    bufferDoubleChar(row, col, c ^ rvsField, &first);
    col += 2;
  }
  
  if (idle && (first >= 0)) { // kick TWI interrupts back into life if necessary
    refreshPtr = first;
    refreshChar();
  }
}

void _display::displayStringLarge(uint8_t row, uint8_t col, const __FlashStringHelper *s, uint8_t rvsField) {
  if (rvsField) { rvsField = 0x80; }
  int16_t first = -1;
  uint8_t *p = (uint8_t *)s;
  while (uint8_t c = pgm_read_byte_near(p++)) {
    bufferDoubleChar(row, col, c ^ rvsField, &first);
    col += 2;
  }
  
  if (idle && (first >= 0)) { // kick TWI interrupts back into life if necessary
    refreshPtr = first;
    refreshChar();
  }
}

#if defined(SH1106) || defined(SSD1306)
uint8_t _display::queueCommands(uint8_t *buff, uint8_t numCommands, uint8_t *commands) { // add command byte (pairs of 00-cmd) to the queued data
  uint8_t bytesAdded = 0;
  
  while (numCommands--) {
    *buff++ = 2; // length of a command
    *buff++ = 0x00; // commands begin with a zero byte
    *buff++ = *commands++;
    bytesAdded += 3;  
  }
  return bytesAdded;
}
#else
uint8_t _display::queueCommands(uint8_t *buff, uint8_t lngth, uint8_t *sequence) { // add byte sequence to the queued data
  *buff++ = lngth; // length of command
  for (uint8_t i = 0; i < lngth; i++) {  
    *buff++ = *sequence++;
  }
  return lngth + 1;
}
#endif

void _display::refreshChar(void) {
  idle = false;
#ifdef DS12864
  uint32_t restTime = refreshPtr < oldRefreshPtr ? 80000UL : 1000UL; // DS12864 display V4.0B seems to need 1ms between I2C packets to allow it to update its buffer and 80ms to allow it to refresh its screen
  oldRefreshPtr = refreshPtr;
  timer1callback::callMethodInMicros(finishRefreshChar, restTime);
}
void _display::finishRefreshChar(void) {
#endif
#ifdef DS160120
  uint32_t restTime = refreshPtr < oldRefreshPtr ? 90000UL : 1500UL; // DS160120 display V4.0B seems to need 1.5ms between I2C packets to allow it to update its buffer and 90ms to allow it to refresh its screen
  oldRefreshPtr = refreshPtr;
  timer1callback::callMethodInMicros(finishRefreshChar, restTime);
}
void _display::finishRefreshChar(void) {
#endif
  refreshed[refreshPtr / 8] |= (1 << (refreshPtr & 0x0007));
  uint8_t c = displayBuffer[refreshPtr] & 0x7F;
#ifdef DS160120
  if (c == 1 ) { // double size character - character code is in next byte
    transmitCharLarge(refreshPtr % 8, (refreshPtr / 8) * 7 + 6, displayBuffer[refreshPtr+1]);    
  } else if (c >= ' ') { // standard size character
    transmitCharSmall(refreshPtr % 8, (refreshPtr / 8) * 7 + 6, displayBuffer[refreshPtr]);
  } else { // soft char 2~31
    transmitSoftCharSmall(refreshPtr % 8, (refreshPtr / 8) * 7 + 6, displayBuffer[refreshPtr]);
  }
#else
  if (c == 1 ) { // double size character - character code is in next byte
    transmitCharLarge(refreshPtr % DISPLAY_CHARHEIGHT, (refreshPtr / DISPLAY_CHARHEIGHT) * 6 + DISPLAY_LEFTMARGIN, displayBuffer[refreshPtr+1]);    
  } else if (c >= ' ') { // standard size character
    transmitCharSmall(refreshPtr % DISPLAY_CHARHEIGHT, (refreshPtr / DISPLAY_CHARHEIGHT) * 6 + DISPLAY_LEFTMARGIN, displayBuffer[refreshPtr]);
  } else { // soft char 2~31
    transmitSoftCharSmall(refreshPtr % DISPLAY_CHARHEIGHT, (refreshPtr / DISPLAY_CHARHEIGHT) * 6 + DISPLAY_LEFTMARGIN, displayBuffer[refreshPtr]);
  }
#endif
}

void _display::transmit(/* uint8_t result */) {
/* no errors (result != 1) occurred during extensive testing - now commenting this out - if error does ever occur, probably best just to keep trying
  if (result != 1) {
    // Serial.print("Callback error: 0x");
    // Serial.print(result, HEX);
    // Serial.print('\n');
  } else if (!*queuePtr) { // queue is empty
 */
  if (!*queuePtr) { // queue is empty
    if (startup) { // still have some vertical-edge-clearing spaces to send
      transmitCharSmall((startup - 1) / 2, startup & 0x01 ? DISPLAY_LCDWIDTH - 6 : 0, ' ');
      startup--;
    } else { // scan for refreshable chars that haven't been refreshed
      uint16_t startRefreshPtr = refreshPtr;
      bool found = false;
      do {
        if (((refreshed[refreshPtr / 8] & (1 << (refreshPtr & 0x0007))) == 0) && (displayBuffer[refreshPtr] != 0)) { // char 0 is a special marker char that doesn't need refreshing
          found = true;
          break; 
        } else if (++refreshPtr == DISPLAY_NUMCHARS) {
          refreshPtr = 0;
        }
      } while (refreshPtr != startRefreshPtr);
      if (found) {
        refreshChar();
      } else {
        idle = true;    
      }
    }
  } else {
    TWI::nonBlockingTWImasterTransmit(DISPLAY_I2C_ADDRESS, queuePtr + 1, *queuePtr, transmit);
    queuePtr += *queuePtr + 1;
  }
}

void _display::transmitCharSmall(uint8_t row, uint8_t x, uint8_t c) {
#if defined(NEGATIVE_DISPLAY) && (defined(SH1106) || defined(SSD1306))
  uint8_t xorMask = c & 0x80 ? 0x00 : 0xFF;  // if MSB set display character reverse field
#else
  uint8_t xorMask = c & 0x80 ? 0xFF : 0x00;  // if MSB set display character reverse field
#endif
#ifdef SH1106
  x += 2;
  uint8_t commandQueue[3] = {(uint8_t)(0xB0 + row), (uint8_t)(x & 0x0F), (uint8_t)(((x >> 4) & 0x0F) | 0x10)};
  uint8_t dataStart = queueCommands(dataBuffer, 3, commandQueue);
  dataBuffer[dataStart++] = 7; // now append a 7-byte data packet
  dataBuffer[dataStart++] = 0x40; // tell display we're sending data not commands
#endif
#ifdef SSD1306
  uint8_t commandQueue[6] = {DISPLAY_PAGEADDR, row, row, DISPLAY_COLUMNADDR, x, x < DISPLAY_LCDWIDTH - 6 ? x + 5 : DISPLAY_LCDWIDTH - 1};
  uint8_t dataStart = queueCommands(dataBuffer, 6, commandQueue);
  dataBuffer[dataStart++] = 7; // now append a 7-byte data packet
  dataBuffer[dataStart++] = 0x40; // tell display we're sending data not commands
#endif
#ifdef DS12864
  uint8_t dataStart = queueCommands(dataBuffer, 6, (uint8_t *)"\x1B\x36\x00\x00\x08\x06"); // "DWWIN - set output window
  dataBuffer[3] = 56 - row * 8;
  dataBuffer[4] = x;

  dataStart += queueCommands(dataBuffer + dataStart, 2, (uint8_t *)"\x1B\x38"); // "WINCL" - Clear output window

  queueCommands(dataBuffer + dataStart, 6, (uint8_t *)"\x1B\x13\x00\x00\x08\x06"); // "DIM" - Draw Image Monochrome
  dataBuffer[dataStart] = 12; // only queued 6 bytes there but it's the start of a 12-byte packet
  dataStart += 7; // allow for the 6 bytes already added, plus the length byte
#endif
#ifdef DS160120
  uint8_t dataStart = queueCommands(dataBuffer, 6, (uint8_t *)"\x1B\x36\x00\x00\x07\x0C"); // "DWWIN - set output window
  dataBuffer[3] = x;
  dataBuffer[4] = row * 12 + 12;

  dataStart += queueCommands(dataBuffer + dataStart, 2, (uint8_t *)"\x1B\x38"); // "WINCL" - Clear output window

  queueCommands(dataBuffer + dataStart, 6, (uint8_t *)"\x1B\x13\x00\x00\x07\x0C"); // "DIM" - Draw Image Monochrome
  dataBuffer[dataStart] = 18; // only queued 6 bytes there but it's the start of a 18-byte packet
  dataStart += 7; // allow for the 6 bytes already added, plus the length byte
#endif

  dataBuffer[dataStart++] = xorMask; // blank column of pixels at left-hand side of character (or top row on DS160120)
#ifdef DS160120
  uint16_t p = ((c & 0x7F) - 32) * 10;
  for (uint8_t i = 0; i < 10; i++) {
    dataBuffer[dataStart++] = pgm_read_byte_near(font + p++) ^ xorMask;
  }
  dataBuffer[dataStart++] = xorMask; // blank column of pixels at bottom row on DS160120)  
#else
  uint16_t p = ((c & 0x7F) - 32) * 5;
  for (uint8_t i = 0; i < 5; i++) {
    dataBuffer[dataStart++] = pgm_read_byte_near(font + p++) ^ xorMask;
  }
#endif
  dataBuffer[dataStart] = 0; // mark end of data with a zero-length packet

  queuePtr = dataBuffer;
  transmit(/* 1 */);
}

void _display::transmitCharLarge(uint8_t row, uint8_t x, uint8_t c) {
#if defined(NEGATIVE_DISPLAY) && (defined(SH1106) || defined(SSD1306))
  uint8_t xorMask = c & 0x80 ? 0x00 : 0xFF;  // if MSB set display character reverse field
#else
  uint8_t xorMask = c & 0x80 ? 0xFF : 0x00;  // if MSB set display character reverse field
#endif
#ifdef SH1106
  // SH1106 (I think) doesn't do vertical addressing mode, so we have to send the top half of the character and then the bottom half
  x += 2;
  uint8_t commandQueue[3] = {(uint8_t)(0xB0 + row), (uint8_t)(x & 0x0F), (uint8_t)(((x >> 4) & 0x0F) | 0x10)}; // position cursor for top half of character
  uint8_t dataStart = queueCommands(dataBuffer, 3, commandQueue);
  dataBuffer[dataStart++] = 13; // now append a 13-byte data packet
  dataBuffer[dataStart++] = 0x40; // tell display we're sending data not commands
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  uint16_t p = ((c & 0x7F) - 32) * 5;

  for (uint16_t i = 2; i < 7; i++) {
    uint8_t top = pgm_read_byte_near(stretch + ((pgm_read_byte_near(font + p++) ^ xorMask) & 0x0F));
    dataBuffer[dataStart++] = top;
    dataBuffer[dataStart++] = top;
  }
  
  commandQueue[0] = 0xB0 + row + 1; // position cursor for bottom half of character
  dataStart += queueCommands(&(dataBuffer[dataStart]), 3, commandQueue);
  dataBuffer[dataStart++] = 13; // now append a 13-byte data packet
  dataBuffer[dataStart++] = 0x40; // tell display we're sending data not commands
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  p = ((c & 0x7F) - 32) * 5;

  for (uint16_t i = 2; i < 7; i++) {
    uint8_t bottom = pgm_read_byte_near(stretch + ((pgm_read_byte_near(font + p++) ^ xorMask) >> 4));
    dataBuffer[dataStart++] = bottom;
    dataBuffer[dataStart++] = bottom;
  }
#endif
#ifdef SSD1306
  uint8_t commandQueue[6] = {DISPLAY_PAGEADDR, row, row+1, DISPLAY_COLUMNADDR, x, x < DISPLAY_LCDWIDTH - 12 ? x + 11 : DISPLAY_LCDWIDTH - 1};
  uint8_t dataStart = queueCommands(dataBuffer, 6, commandQueue);

  dataBuffer[dataStart++] = 25; // now append a 25-byte data packet
  dataBuffer[dataStart++] = 0x40; // tell display we're sending data not commands
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; // blank column two pixels wide (and 16 high) at left-hand side of character

  uint16_t p = ((c & 0x7F) - 32) * 5;

  for (uint16_t i = 2; i < 7; i++) {
    c = pgm_read_byte_near(font + p++) ^ xorMask;
    uint8_t top = pgm_read_byte_near(stretch + (c & 0x0F));
    uint8_t bottom = pgm_read_byte_near(stretch + (c >> 4));
    dataBuffer[dataStart++] = top;
    dataBuffer[dataStart++] = bottom;
    dataBuffer[dataStart++] = top;
    dataBuffer[dataStart++] = bottom;
  }
#endif
#ifdef DS12864
  uint8_t dataStart = queueCommands(dataBuffer, 6, (uint8_t *)"\x1B\x36\x00\x00\x10\x0C"); // "DWWIN - set output window
  dataBuffer[3] = 48 - row * 8;
  dataBuffer[4] = x;

  dataStart += queueCommands(dataBuffer + dataStart, 2, (uint8_t *)"\x1B\x38"); // "WINCL" - Clear output window

  queueCommands(dataBuffer + dataStart, 6, (uint8_t *)"\x1B\x13\x00\x00\x10\x0C"); // "DIM" - Draw Image Monochrome
  dataBuffer[dataStart] = 30; // only queued 6 bytes there but it's the start of a 30-byte packet
  dataStart += 7; // allow for the 6 bytes already added, plus the length byte

  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; // blank column two pixels wide (and 16 high) at left-hand side of character

  uint16_t p = ((c & 0x7F) - 32) * 5;

  for (uint16_t i = 2; i < 7; i++) {
    c = pgm_read_byte_near(font + p++) ^ xorMask;
    uint8_t top = pgm_read_byte_near(stretch + (c & 0x0F));
    uint8_t bottom = pgm_read_byte_near(stretch + (c >> 4));
    dataBuffer[dataStart++] = bottom;
    dataBuffer[dataStart++] = top;
    dataBuffer[dataStart++] = bottom;
    dataBuffer[dataStart++] = top;
  }
#endif
#ifdef DS160120
  uint8_t dataStart = queueCommands(dataBuffer, 6, (uint8_t *)"\x1B\x36\x00\x00\x0E\x18"); // "DWWIN - set output window
  dataBuffer[3] = x;
  dataBuffer[4] = row * 12 + 12;

  dataStart += queueCommands(dataBuffer + dataStart, 2, (uint8_t *)"\x1B\x38"); // "WINCL" - Clear output window

  queueCommands(dataBuffer + dataStart, 6, (uint8_t *)"\x1B\x13\x00\x00\x0E\x0C"); // "DIM" - Draw Image Monochrome
  dataBuffer[dataStart] = 30; // only queued 6 bytes there but it's the start of a 30-byte packet
  dataStart += 7; // allow for the 6 bytes already added, plus the length byte

  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; // blank row two pixels high (and 14 wide) at top of character

  uint16_t p = ((c & 0x7F) - 32) * 10;

  for (uint16_t i = 0; i < 5; i++) {
    uint8_t b = pgm_read_byte_near(font + p++);
    uint8_t left = pgm_read_byte_near(stretch + (uint8_t)((b >> 4) & 0x0F)) ^ xorMask;
    uint8_t right = (pgm_read_byte_near(stretch + (uint8_t)((b >> 1) & 0x07)) ^ xorMask) << 2;
    dataBuffer[dataStart++] = left;
    dataBuffer[dataStart++] = right;
    dataBuffer[dataStart++] = left;
    dataBuffer[dataStart++] = right;
  }

  queueCommands(dataBuffer + dataStart, 6, (uint8_t *)"\x1B\x13\x00\x0C\x0E\x0C"); // "DIM" - Draw Image Monochrome - have to do it in two packets like this as display doesn't seem to handle 14 or more rows of pixels each 14 pixels wide
  dataBuffer[dataStart] = 30; // only queued 6 bytes there but it's the start of a 30-byte packet
  dataStart += 7; // allow for the 6 bytes already added, plus the length byte
  
  p = ((c & 0x7F) - 32) * 10 + 5;

  for (uint16_t i = 0; i < 5; i++) {
    uint8_t b = pgm_read_byte_near(font + p++);
    uint8_t left = pgm_read_byte_near(stretch + (uint8_t)((b >> 4) & 0x0F)) ^ xorMask;
    uint8_t right = (pgm_read_byte_near(stretch + (uint8_t)((b >> 1) & 0x07)) ^ xorMask) << 2;
    dataBuffer[dataStart++] = left;
    dataBuffer[dataStart++] = right;
    dataBuffer[dataStart++] = left;
    dataBuffer[dataStart++] = right;
  }

  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; 
  dataBuffer[dataStart++] = xorMask; // blank row two pixels high (and 14 wide) at bottom of character
#endif
  dataBuffer[dataStart] = 0; // mark end of data with a zero-length packet
  queuePtr = dataBuffer;
  transmit(/* 1 */);
}

void _display::transmitSoftCharSmall(uint8_t row, uint8_t x, uint8_t c) {
#if defined(NEGATIVE_DISPLAY) && (defined(SH1106) || defined(SSD1306))
  uint8_t xorMask = c & 0x80 ? 0x00 : 0xFF;  // if MSB set display character reverse field
#else
  uint8_t xorMask = c & 0x80 ? 0xFF : 0x00;  // if MSB set display character reverse field
#endif
#ifdef SH1106
  x += 2;
  uint8_t commandQueue[3] = {(uint8_t)(0xB0 + row), (uint8_t)(x & 0x0F), (uint8_t)(((x >> 4) & 0x0F) | 0x10)};
  uint8_t dataStart = queueCommands(dataBuffer, 3, commandQueue);
  dataBuffer[dataStart++] = 7; // now append a 7-byte data packet
  dataBuffer[dataStart++] = 0x40; // tell display we're sending data not commands
#endif
#ifdef SSD1306
  uint8_t commandQueue[6] = {DISPLAY_PAGEADDR, row, row, DISPLAY_COLUMNADDR, x, x < DISPLAY_LCDWIDTH - 6 ? x + 5 : DISPLAY_LCDWIDTH - 1};
  uint8_t dataStart = queueCommands(dataBuffer, 6, commandQueue);
  dataBuffer[dataStart++] = 7; // now append a 7-byte data packet
  dataBuffer[dataStart++] = 0x40; // tell display we're sending data not commands
#endif
#ifdef DS12864
  uint8_t dataStart = queueCommands(dataBuffer, 6, (uint8_t *)"\x1B\x36\x00\x00\x08\x06"); // "DWWIN - set output window
  dataBuffer[3] = 56 - row * 8;
  dataBuffer[4] = x;

  dataStart += queueCommands(dataBuffer + dataStart, 2, (uint8_t *)"\x1B\x38"); // "WINCL" - Clear output window

  queueCommands(dataBuffer + dataStart, 6, (uint8_t *)"\x1B\x13\x00\x00\x08\x06"); // "DIM" - Draw Image Monochrome
  dataBuffer[dataStart] = 12; // only queued 6 bytes there but it's the start of a 12-byte packet
  dataStart += 7; // allow for the 6 bytes already added, plus the length byte
#endif
#ifdef DS160120
  uint8_t dataStart = queueCommands(dataBuffer, 6, (uint8_t *)"\x1B\x36\x00\x00\x07\x0C"); // "DWWIN - set output window
  dataBuffer[3] = x;
  dataBuffer[4] = row * 12 + 12;

  dataStart += queueCommands(dataBuffer + dataStart, 2, (uint8_t *)"\x1B\x38"); // "WINCL" - Clear output window

  queueCommands(dataBuffer + dataStart, 6, (uint8_t *)"\x1B\x13\x00\x00\x07\x0C"); // "DIM" - Draw Image Monochrome
  dataBuffer[dataStart] = 18; // only queued 6 bytes there but it's the start of an 18-byte packet
  dataStart += 7; // allow for the 6 bytes already added, plus the length byte
  uint8_t *p = scBuffer + ((c & 0x7F) - 2) * 12;
  for (uint8_t i = 0; i < 12; i++) {
#else
  uint8_t *p = scBuffer + ((c & 0x7F) - 2) * 6;
  for (uint8_t i = 0; i < 6; i++) {
#endif
    dataBuffer[dataStart++] = *p++ ^ xorMask;
  }

  dataBuffer[dataStart] = 0; // mark end of data with a zero-length packet
  queuePtr = dataBuffer;
  transmit(/* 1 */);
}

void _display::scClear(uint8_t c) { // clear soft character c = 2~31
  if ((c >= 2) && (c <= 31)) {
#ifdef DS160120
    uint8_t *p = scBuffer + (c - 2) * 12;
    for (uint8_t i = 0; i < 12; i++) {
#else
    uint8_t *p = scBuffer + (c - 2) * 6;
    for (uint8_t i = 0; i < 6; i++) {
#endif
      *p++ = 0x00;
    }
    softCharChanged |= 0x01UL << c;
  }
}
#ifdef DS160120
void _display::scSetPixel(uint8_t c, uint8_t p) { // set pixel in soft character c = 2~31, p = 0~94 starting top left in reading order, but (p % 8) == 7 is invalid.  p % 8 gives x coordinate, p / 8 gives y
  if ((c >= 2) && (c <= 31) && (p <= 94)) {
    scBuffer[(c - 2) * 12 + p / 8] |= (0x80 >> (p & 0x07));
    softCharChanged |= 0x01UL << c;
  }
}

void _display::scResetPixel(uint8_t c, uint8_t p) {
  if ((c >= 2) && (c <= 31) && (p <= 94)) {
    scBuffer[(c - 2) * 12 + p / 8] &= ~(0x80 >> (p & 0x07));
    softCharChanged |= 0x01UL << c;
  }
}
#else
void _display::scSetPixel(uint8_t c, uint8_t p) { // set pixel in soft character c = 2~31, p = 0~47 starting top left  p = 7 is bottom left, p = 47 is bottom right
  if ((c >= 2) && (c <= 31) && (p <= 47)) {
    scBuffer[(c - 2) * 6 + p / 8] |= (1 << (p & 0x07));
    softCharChanged |= 0x01UL << c;
  }
}

void _display::scResetPixel(uint8_t c, uint8_t p) {
  if ((c >= 2) && (c <= 31) && (p <= 47)) {
    scBuffer[(c - 2) * 6 + p / 8] &= ~(1 << (p & 0x07));
    softCharChanged |= 0x01UL << c;
  }
}
#endif
