// SBUS decoder
// SBUS into RX0 via transistor inverter
// Optional I2C OLED display on A4/A5
// n-channel CPPM output on D9
// original version: ceptimus June 2020
// sbusDecode5 version, April 2022 corrected a few minor bugs
// this sbusDecode6 version, January 2023, allows more than 8 channels of PPM.
// defaults to 12 channels of PPM, but edit NUM_PPM_CHANNELS in config.h to alter:
// set NUM_PPM_CHANNELS somewhere in range 8 to 18.  More channels of PPM results in a slower PPM frame rate.

#include "display.h"
#include "cppm_out.h"

enum DisplayMode { ElevenBit, Microseconds, Percentages };
DisplayMode displayMode = ElevenBit; // choose one of the DisplayMode options here for the start-up default

// if you choose to fit a momentary contact button to the selected pin (8 here) it will cycle through the display modes
#define MODE_BUTTON 8

// alter the MICROSECOND_SCALING ranges below to set the SBUS to Microseconds scaling you want
// order of numbers is SBUS low value, SBUS high value, Microseconds low value, Microseconds high value
// commas between the numbers and no other punctuation or comments on the line
#define MICROSECOND_SCALING 0, 2047, 988, 2011

// similarly for the PERCENT_SCALING
#define PERCENT_SCALING 0, 2047, -100, 100

uint8_t frame[24]; // SBUS received bytes. 1st byte of 25-byte frame is always 0x0F, and is not stored
char buffer[22]; // printing to OLED display
bool displayCleared;

void setup() {
  pinMode(MODE_BUTTON, INPUT_PULLUP);
  _display::start();
  displayBackground();
  // SBUS runs at 100kBaud 8E2. Each 25-byte frame, without gaps, takes 3000us
  Serial.begin(100000, SERIAL_8E2);
  for (int i = 0; i < NUM_PPM_CHANNELS; i++) {
    cppm_out::set(i, 0); // default most cppm channel values to nominal centre
  }
  // start sending 8-channel cppm signal 22.5ms frame, 400us low-going pulses on D9
  cppm_out::set(0, -850); // default channel '1' (Spektrum throttle) to low until SBUS received
  cppm_out::set(2, -850); // default channel '3' (Futaba throttle) to low
  cppm_out::start();
}

void showDisplayMode() {
  switch (displayMode) {
    case ElevenBit:
      _display::displayStringSmall(0, 3, F("( SBUS )"), 0);
      break;
    case Microseconds:
      _display::displayStringSmall(0, 3, F("(PPM \x7Fs)"), 0);
      break;
    case Percentages:
      _display::displayStringSmall(0, 3, F("(Percnt)"), 0);
      break;
    default:
      _display::displayStringSmall(0, 3, F("(  ??  )"), 0);
      break;
  }
}

void displayBackground() {
  _display::fillDisplay(' ');
  _display::displayStringSmall(0, 0, F("Ch"), 0);
  _display::displayStringSmall(0, 18, F("ms"), 0);
  for (int row = 1; row < 7; row++) {
    int i = row * 3 - 2; // channel number label: 1, 4, 7, 10, 13, 16
    sprintf(buffer, "%2d:", i);
    _display::displayStringSmall(row, 0, buffer, 0);
  }
  _display::displayStringLarge(2, 3, F(" No SBUS "), 1);
  _display::displayStringLarge(4, 3, F(" Signal  "), 1);
  _display::displayStringSmall(7, 0, F("  ceptimus  Feb 2021 "), 1);
  displayCleared = true;
  showDisplayMode();
}

int channel(int ch) { // extract 11-bit channel[ch] value from frame. ch 0-15
  int k = ch > 7 ? 11 : 0; // offset into frame array: 0 for channels 0-7, 12 for channels 8-15
  switch (ch % 8) { // pattern repeats (except for k-offset) after 8 channels
    case 0:
      return (int)frame[0+k] | ((((int)frame[1+k]) & 0x07) << 8);
    case 1:
      return ((int)(frame[1+k] & 0xF8) >> 3) | ((((int)frame[2+k]) & 0x3F) << 5);
    case 2:
      return ((int)(frame[2+k] & 0xC0) >> 6) | ((((int)frame[3+k])) << 2) | ((((int)frame[4+k]) & 0x01) << 10);
    case 3:
      return ((int)(frame[4+k] & 0xFE) >> 1) | ((((int)frame[5+k]) & 0x0F) << 7);
    case 4:
      return ((int)(frame[5+k] & 0xF0) >> 4) | ((((int)frame[6+k]) & 0x7F) << 4);
    case 5:
      return ((int)(frame[6+k] & 0x80) >> 7) | ((((int)frame[7+k])) << 1) | ((((int)frame[8+k]) & 0x03) << 9);
    case 6:
      return ((int)(frame[8+k] & 0xFC) >> 2) | ((((int)frame[9+k]) & 0x1F) << 6);
    case 7:
      return ((int)(frame[9+k] & 0xE0) >> 5) | (((int)frame[10+k]) << 3);
  }
  return -1; // execution never reaches here, but this supresses a compliler warning
}

uint32_t debounceModeButton = 0UL;
void loop() {
  if ((debounceModeButton - millis()) > 0x80000000UL) {
    if (!digitalRead(MODE_BUTTON)) { // change display mode
      switch (displayMode) {
        case ElevenBit:
          displayMode = Microseconds;
          break;
        case Microseconds:
          displayMode = Percentages;
          break;
        default:
          displayMode = ElevenBit;
          break;
      }
      showDisplayMode();
      debounceModeButton = millis() + 700; // wait 0.7s before next change
    }
  }
  static uint32_t previousFrameReceivedAt = 0UL; // timing SBUS frame intervals
  static uint32_t lastDisplayUpdate = 0UL; // for slowing display update to make more readable
  
  bool frameReceived = false;
  uint32_t frameBeganAt = micros();
  while(Serial.available()) {
    // try to receive a 25-byte frame that begins with 0x0F and ends with 0x00
    // scan until an 0x0F byte is received, or the receive buffer is empty
    int b = Serial.read();
    if (b != 0x0F) {
      frameBeganAt = micros(); 
      continue;
    }
    frame[23] = 0xFF; // a good received frame overwrites this with 0x00
    // now attempt to receive 24 bytes, or time out and abort after 4ms
    int i = 0;
    while (i < 24) {
      if ((micros() - frameBeganAt) > 4000) {
        break;
      }
      i += Serial.readBytes(frame + i, min(Serial.available(), 24 - i));
    }
    if (i == 24 && frame[23] == 0x000) {
      frameReceived = true;
      break;
    }
  }
  uint32_t now = micros();
  uint32_t elapsedMicros = now - previousFrameReceivedAt;
  if (frameReceived) {
    previousFrameReceivedAt = now;
    // copy first NUM_PPM_CHANNELS received in SBUS frame to CPPM outputs
    int sbus[NUM_PPM_CHANNELS];
    for (int i = 0; i < NUM_PPM_CHANNELS; i++) {
      sbus[i] = channel(i);
      cppm_out::set_us(i, map(sbus[i], MICROSECOND_SCALING));
    }
    // only refresh display three times per second - makes fast-changing values more readable
    uint32_t e = now - lastDisplayUpdate;
    if (e > 333333UL) {
      if (displayCleared) { // remove 'No SBUS message' 
        for (int i = 2; i < 7; i++) {
          _display::displayStringSmall(i, 3, F("                  "), 0);
        }
      }
      // display latest time between frames to nearest 0.1ms
      elapsedMicros += 50; // dividing by 100 to get 0.1ms, so add 50 to round to nearest
      sprintf(buffer, "%4ld", elapsedMicros / 1000UL); // formatting done in two integer stages to avoid floats
      buffer[4] = '.';
      buffer[5] = (char)((elapsedMicros % 1000UL) / 100UL + '0');
      buffer[6] = '\0'; // terminate string
      _display::displayStringSmall(0, 11, buffer, 0);
      for (int i = 0; i < 16; i++) { // an SBUS frame has 16 11-bit channels
        // have already extracted the first 8 channels for the CPPM signal
        int sbus11bit = (i < 8) ? sbus[i] : channel(i);
        int microsecs, percent;
        switch (displayMode) {
          case ElevenBit:
            sprintf(buffer, "%5d", sbus11bit);
            break;
          case Microseconds:
            // may need to change scaling to suit different manufacturers
            microsecs = map(sbus11bit, MICROSECOND_SCALING);
            sprintf(buffer, "%5d", microsecs);
            break;
          case Percentages:
            // may need to change scaling to suit different manufacturers
            percent = map(sbus11bit, PERCENT_SCALING);
            sprintf(buffer, "%4d%%", percent);
            break;
          default:
            sprintf(buffer, "?????");
            break;
        }
        _display::displayStringSmall(i / 3 + 1, (i % 3) * 6 + 4, buffer, 0);
      }
      _display::displayCharSmall(6, 14, frame[22] & 0x01 ? '1' : '0', 0); // digital channel 17
      _display::displayCharSmall(6, 20, frame[22] & 0x02 ? '1' : '0', 0); // digital channel 18
      _display::displayStringSmall(7, 0, frame[22] & 0x04 ? F("Frame lost ") : F("           "), 0); // Frame lost flag
      _display::displayStringSmall(7, 11, frame[22] & 0x08 ? F("  Failsafe") : F("          "), 0); // Failsafe flag
      lastDisplayUpdate = now;
      displayCleared = false;
    }
  } else if ((elapsedMicros > 2000000UL) && !displayCleared) { // no frame during last 2 seconds
    displayBackground();
  }
}
