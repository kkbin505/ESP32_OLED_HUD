#ifndef cppm_out_h
#define cppm_out_h

#include "config.h"

// driving n-channel cppm signal on pin 9 (PB1) using Timer 2 interrupts - ceptimus 2023-01-05
// set number of PPM channels (8 to 18) by editing NUM_PPM_CHANNELS value in config.h

// default signal is low-going pulses that are actively driven high and low.
// you can comment/uncomment options in config.h if you want high-going pulses, or 'open collector' style drive

class cppm_out {
  public:
    // pulse intervals in half-microsecond units - varies approx 1600~4400 with centre at ~3000 but with 800 subtracted for 400 uS low pulse
    // don't set these directly - they are public as they are accessed from the (non class member) interrupt service routine
    // but to set the 16-bit quantity in an interrupt safe way, use the set() method
    static volatile uint16_t pulseWidth[NUM_PPM_CHANNELS]; // pulse widths in half-microseconds

    static void start(void); // call from setup() to initialise output pin, interrupts etc and begin outputting signal
    static void set(uint8_t n, int16_t p); // set channel[n] to position p. n is channel 0 to 7. p ~ +/- 1400
    static void set_us(uint8_t n, int16_t us); // set channel[n] pulse time to us
    static int16_t get_us(uint8_t n); // return current channel[n] pulse time in us
};
#endif
