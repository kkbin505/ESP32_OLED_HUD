#include "cppm_out.h"

// pulse spacings in half-microseconds, all have 800 subtracted to allow for 400 us pulse
volatile uint16_t cppm_out::pulseWidth[NUM_PPM_CHANNELS]; 

void cppm_out::start(void) { // start driving NUM_PPM_CHANNELS cppm on D9

// with OPEN_OUTPUT there's no need for an RF-module-protecting Schottky diode
#ifdef OPEN_OUTPUT 
  PORTB &= ~_BV(1); // preseting D9 to go low only when it's enabled as an output
# ifdef PULSES_LOW
  DDRB &= ~_BV(1); // for low-going pulses, normal state of pin is high impedance (input) and the RF module will pull it high
# else
  DDRB |= _BV(1); // for high-going pulses, normal state of pin is output - and as the PORTB bit is permanently low this will be a low output
# endif
#else
// OPEN_OUTPUT is not defined so we set up the pin as a regular active output
  pinMode(9, OUTPUT);
# ifdef PULSES_LOW
  digitalWrite(9, HIGH); // for low-going pulses, normal state of pin is high
# else
  digitalWrite(9, LOW); // for high-going pulses, normal state of pin is low
# endif
#endif
    
  // initialize counter 2 for pulse output duties
  TCCR2A = 0x02; // CTC mode (Clear Timer on Compare Match)
  TCCR2B = 0x02; // prescale = clk/8: count at 2MHz
  OCR2A = 0xFF; // default count target (256 counts per cycle)
  TIMSK2 = 0x02; // Compare Match A Interrupt Enable
}

// driving NUM_PPM_CHANNELS cppm on Digital 9 (PB1) using Timer 2 interrupts - original 8-channel version ceptimus 2015-06-25
// this N-channel version ceptimus 2023-01-5
// pulses are all 400us wide. From one +ve edge to next separated by 800us to 2200us.
// frame is (NUM_PPM_CHANNELS * 2.2 + 4) ms long)
// channels  ms
//     8    21.6
//     9    23.8
//    10    26.0
//    11    28.2
//    12    30.4 * default for unmodified sbusDecode6 - but edit NUM_PPM_CHANNELS in config.h to change
//    13    32.6
//    14    34.8
//    15    37.0
//    16    39.2
//    17    41.4
//    18    43.6

ISR(TIMER2_COMPA_vect) {
  static uint8_t cycles = 0;
  static uint8_t finalCount;
  static uint8_t stage = 0;
  static uint16_t syncWidth = NUM_PPM_CHANNELS * 3600 + 7200;
  if (!cycles) { // time to switch an output
    uint16_t width;
    if (!(stage & 0x01)) { // at even stages, start 400 us pulse
#ifdef OPEN_OUTPUT
# ifdef PULSES_LOW
      DDRB |= _BV(1); // enable D9 as output.  Port B bit 1 was initialized to low, so this makes D9 pull low - pulse train is mostly high with low pulses
# else
      DDRB &= ~_BV(1); // disable D9 as output thus allowing the RF module to pull it high
# endif
#else
# ifdef PULSES_LOW
      PORTB &= ~_BV(1); // active output with low-going pulses - drive the output low
# else
      PORTB |= _BV(1); // active output with high-going pulses - drive the output high
# endif
#endif
      width = 800; // pulse time in half-micro seconds
    }
    else { // at odd stages end 400 us pulse
#ifdef OPEN_OUTPUT
# ifdef PULSES_LOW
      DDRB &= ~_BV(1); // disable D9 as output thus allowing the RF module to pull it high
# else
      DDRB |= _BV(1); // enable D9 as output.  Port B bit 1 was initialized to low, so this makes D9 pull low - pulse train is mostly low with high pulses
# endif
#else
# ifdef PULSES_LOW
      PORTB |= _BV(1); // active output with high-going pulses - drive the output high
# else
      PORTB &= ~_BV(1); // active output with low-going pulses - drive the output low
# endif
#endif
      if (stage == NUM_PPM_CHANNELS * 2 + 1) { // final stage so now output the sync pulse
        width = syncWidth;
        syncWidth = NUM_PPM_CHANNELS * 3600 + 7200;
      }
      else {
        width = cppm_out::pulseWidth[stage / 2];
        syncWidth -= width;
      }
    }
    if ((width & 0x00FF) < 50) { // if finalCount would be less than 50 with the default target at 0xFF
      uint8_t adjust = (50 - (width & 0x00FF)) / (width >> 8) + 1;
      OCR2A = 0x100 - adjust;
      cycles = width >> 8;
      finalCount = (width & 0xFF) + adjust * cycles - 1;
    }
    else { // okay to use default 0xFF count value for all but last cycle
      OCR2A = 0xFF;
      cycles = width >> 8;
      finalCount = (width & 0xFF) - 1;
    }  
    if (++stage > NUM_PPM_CHANNELS * 2 + 1) { // move to next stage (18 stages for the 9 pulse edges)
        stage = 0;
    }
  }
  else if (cycles-- == 1) { // last cycle, load the remaining count target
    OCR2A = finalCount;
  }
}

void cppm_out::set(uint8_t n, int16_t p) {
  p += 2200; // nominal ppm (like edge to like edge) width is 1500 us, but that includes the 400 us  pulse
  if (p < 800) { // limit range to 800us - 2200us ( x 2 - 800 to convert to counts less 800 for pulse)
    p = 800;
  }
  else if (p > 3600) {
    p = 3600;
  }
  volatile uint16_t *ptr;
  ptr = pulseWidth + n;
  uint8_t SaveSREG = SREG;
  cli();
  *ptr = p;
  SREG = SaveSREG; // this is more complicated than just cli() and sei() but allows this function to be called from main program OR from within another interrupt
}

void cppm_out::set_us(uint8_t n, int16_t us) {
  set(n, (us - 1500) * 2);
}

int16_t cppm_out::get_us(uint8_t n) {
  int16_t p = (int16_t)pulseWidth[n] - 2200;
  return p / 2 + 1500;
}
