// config.h file for SBUS decoder and display/CPPM out.  Edit the options here and recompile/upload.
#ifndef config_h
#define config_h
#include <Arduino.h>

// define only one of these supported display types - leave the others commented out. SH1106 is normal for 1.3-inch OLEDS; SSD1306 is normal for 0.96-inch OLEDS; 
// DS12864 is the 1.8-inch daylight-readable Digole DS12864LCD-4
// DS160120 is the 2-inch daylight-readable Digole DS160120LCD-51 
#define SH1106
// #define SSD1306
// #define DS12864
// #define DS160120

// The OLED displays default to a dark background and the Digole displays to a bright one.  Remove the commenting-out slashes on the following line to swap to the alternative
// #define NEGATIVE_DISPLAY

// number of PPM channels output.  Up to 18, but more channels result in a slower update rate - see chart in cppm_out.cpp
#define NUM_PPM_CHANNELS 12

// comment out (with // ) the following line if you want high-going CPPM pulses instead of low-going ones
#define PULSES_LOW

// if you want your CPPM signal to only be pulled low, and let it float high, remove the commenting-out // from the following line 
// #define OPEN_OUTPUT

// I2C addresses for the supported display types.  OLEDS are normally 0x3C, sometimes 0x3D. Digole DS12864LCD-51 defaults to 0x27 but can be altered to other values.  Edit the one for your display type if it's different
#define SH1106_ADDR 0x3C
#define SSD1306_ADDR 0x3C
#define DS12864_ADDR 0x27
#define DS160120_ADDR 0x27

#endif
